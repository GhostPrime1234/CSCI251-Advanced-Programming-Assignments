//
// Created by Michael on 30/09/2024.
//

#include "People.h"
// People class implementation
People::People(double popularity) : popularity(popularity) {}


